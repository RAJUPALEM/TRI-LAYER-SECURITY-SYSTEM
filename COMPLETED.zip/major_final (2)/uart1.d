uart1.o: uart1.c
uart1.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.H
uart1.o: C:\KeilARM\ARM\RV31\INC\string.h
